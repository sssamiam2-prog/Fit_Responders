
export type Exercise = {
  name: string;
  alt?: string;
};

export type Program = {
  id: string;
  name: string;
  daysPerWeek: number;
  split: string;
  exercises: Exercise[];
};

type Library = {
  PPL: Program[];
  'Upper-Lower': Program[];
  'Mini Cut': Program[];
  'Show Prep': Program[];
};

export const samplePrograms: Library = {
  PPL: [
    {
      id: 'ppl-1',
      name: 'PPL Foundation',
      daysPerWeek: 6,
      split: 'Push/Pull/Legs',
      exercises: [
        { name: 'Barbell Bench Press', alt: 'Dumbbell Bench Press' },
        { name: 'Barbell Row', alt: 'Single-arm DB Row' },
        { name: 'Barbell Squat', alt: 'Goblet Squat' },
        { name: 'Overhead Press', alt: 'DB Shoulder Press' },
        { name: 'Romanian Deadlift', alt: 'DB RDL' },
      ],
    },
    {
      id: 'ppl-2',
      name: 'PPL Strength Bias',
      daysPerWeek: 5,
      split: 'Push/Pull/Legs',
      exercises: [
        { name: 'Barbell Bench Press', alt: 'DB Bench Press' },
        { name: 'Weighted Pull-up', alt: 'Lat Pulldown' },
        { name: 'Barbell Squat', alt: 'Hack Squat' },
        { name: 'Deadlift', alt: 'Trap Bar Deadlift' },
      ],
    },
  ],
  'Upper-Lower': [
    {
      id: 'ul-1',
      name: 'Upper Lower Classic',
      daysPerWeek: 4,
      split: 'Upper/Lower',
      exercises: [
        { name: 'Barbell Incline Bench', alt: 'DB Incline Bench' },
        { name: 'Seated Row', alt: 'Chest Supported Row' },
        { name: 'Leg Press', alt: 'Goblet Squat' },
        { name: 'Hamstring Curl', alt: 'DB RDL' },
      ],
    },
  ],
  'Mini Cut': [
    {
      id: 'mc-1',
      name: 'Mini Cut – Lighter',
      daysPerWeek: 4,
      split: 'Full Body',
      exercises: [
        { name: 'Front Squat', alt: 'Goblet Squat' },
        { name: 'Incline DB Bench' },
        { name: 'Cable Row' },
        { name: 'Leg Curl' },
      ],
    },
  ],
  'Show Prep': [
    {
      id: 'sp-1',
      name: 'Prep – Hypertrophy',
      daysPerWeek: 6,
      split: 'PPL',
      exercises: [
        { name: 'Barbell Bench Press', alt: 'DB Bench Press' },
        { name: 'Barbell Row', alt: 'Chest Supported Row' },
        { name: 'Hack Squat' },
        { name: 'Lateral Raise' },
      ],
    },
  ],
};
