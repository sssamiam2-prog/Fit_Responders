
import Svg, { Path } from 'react-native-svg';
import { View } from 'react-native';
import { colors } from '../styles/commonStyles';

type Props = {
  data: number[];
  height?: number;
  color?: string;
};

export default function Graph({ data, height = 120, color = colors.primary }: Props) {
  const width = 300;
  const max = Math.max(1, ...data);
  const min = Math.min(...data);
  const pad = 6;
  const span = max - min || 1;

  const points = data.map((v, i) => {
    const x = pad + (i / Math.max(1, data.length - 1)) * (width - pad * 2);
    const y = pad + (1 - (v - min) / span) * (height - pad * 2);
    return `${x},${y}`;
  });
  const d = `M ${points.join(' L ')}`;

  return (
    <View style={{ width, height, alignSelf: 'center' }}>
      <Svg width={width} height={height}>
        <Path d={d} stroke={color} strokeWidth={3} fill="none" />
      </Svg>
    </View>
  );
}
