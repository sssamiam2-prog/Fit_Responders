
import { useMemo, useRef, useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import BottomSheet, { BottomSheetBackdrop, BottomSheetView } from '@gorhom/bottom-sheet';
import { colors } from '../styles/commonStyles';

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title?: string;
  children?: React.ReactNode;
};

export default function BottomSheetModal({ open, onOpenChange, title, children }: Props) {
  const ref = useRef<BottomSheet>(null);
  const snapPoints = useMemo(() => ['40%', '70%'], []);

  useEffect(() => {
    if (open) {
      ref.current?.expand();
    } else {
      ref.current?.close();
    }
  }, [open]);

  return (
    <BottomSheet
      ref={ref}
      index={-1}
      enablePanDownToClose
      onClose={() => onOpenChange(false)}
      snapPoints={snapPoints}
      backdropComponent={(props) => <BottomSheetBackdrop {...props} appearsOnIndex={0} disappearsOnIndex={-1} />}
    >
      <BottomSheetView style={styles.content}>
        {title ? <Text style={styles.title}>{title}</Text> : null}
        <View style={{ display: 'contents' }}>{children}</View>
      </BottomSheetView>
    </BottomSheet>
  );
}

const styles = StyleSheet.create({
  content: {
    padding: 16,
    backgroundColor: colors.card,
  },
  title: {
    color: colors.text,
    fontWeight: '800',
    fontSize: 16,
    marginBottom: 8,
  },
});
