
import { View, Text, StyleSheet } from 'react-native';
import { colors } from '../styles/commonStyles';
import Button from './Button';

type Exercise = {
  name: string;
  alt?: string; // DB variant
};

type Program = {
  id: string;
  name: string;
  daysPerWeek: number;
  split: string;
  exercises: Exercise[]; // preview
};

type Props = {
  program: Program;
  hasBarbell: boolean;
  onAssign: (program: Program) => void;
};

export default function ProgramCard({ program, hasBarbell, onAssign }: Props) {
  const preview = program.exercises.slice(0, 4);
  const swap = (name: string, alt?: string) => {
    if (name.toLowerCase().includes('barbell') && !hasBarbell && alt) return alt;
    return name;
    };
  return (
    <View style={styles.card}>
      <Text style={styles.title}>{program.name}</Text>
      <Text style={styles.subtitle}>{program.split} • {program.daysPerWeek}d/wk</Text>
      <View style={{ marginTop: 8 }}>
        {preview.map((e, idx) => (
          <Text key={idx} style={styles.item}>• {swap(e.name, e.alt)}</Text>
        ))}
      </View>
      <Button text="Assign Program" onPress={() => onAssign(program)} />
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 12,
    marginBottom: 12,
    boxShadow: '0 2px 6px rgba(0,0,0,0.08)',
  },
  title: {
    color: colors.text,
    fontWeight: '800',
    fontSize: 16,
  },
  subtitle: {
    color: colors.textMuted,
    marginTop: 2,
  },
  item: {
    color: colors.text,
    marginBottom: 4,
  },
});
