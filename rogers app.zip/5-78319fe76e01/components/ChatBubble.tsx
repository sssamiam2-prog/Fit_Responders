
import { View, Text, StyleSheet } from 'react-native';
import { colors } from '../styles/commonStyles';
import dayjs from 'dayjs';

type Message = {
  id: string;
  text: string;
  from: 'client' | 'coach';
  urgent?: boolean;
  system?: boolean;
  timestamp: string;
  voiceNote?: { durationSec: number; url?: string };
};

export default function ChatBubble({ message }: { message: Message }) {
  const fromClient = message.from === 'client';
  return (
    <View style={[styles.row, { justifyContent: fromClient ? 'flex-end' : 'flex-start' }]}>
      <View
        style={[
          styles.bubble,
          {
            backgroundColor: fromClient ? (message.urgent ? colors.secondary : colors.primary) : colors.card,
            alignSelf: fromClient ? 'flex-end' : 'flex-start',
          },
        ]}
      >
        <Text style={[styles.text, { color: fromClient ? '#fff' : colors.text }]}>{message.text}</Text>
        {message.voiceNote ? (
          <Text style={[styles.voice, { color: fromClient ? '#fff' : colors.text }]}>
            🎤 {message.voiceNote.durationSec}s
          </Text>
        ) : null}
        <Text style={[styles.time, { color: fromClient ? '#fff' : colors.textMuted }]}>
          {dayjs(message.timestamp).format('MMM D, HH:mm')}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  bubble: {
    maxWidth: '80%',
    padding: 10,
    borderRadius: 12,
    boxShadow: '0 1px 3px rgba(0,0,0,0.12)',
  },
  text: {
    fontSize: 14,
    fontWeight: '600',
  },
  voice: {
    fontSize: 13,
    marginTop: 4,
  },
  time: {
    fontSize: 11,
    marginTop: 4,
  },
});
