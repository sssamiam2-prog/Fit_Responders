
import { useEffect, useMemo, useRef, useState } from 'react';
import { View, Text, StyleSheet, Platform, TextInput } from 'react-native';
import BottomSheetModal from './BottomSheetModal';
import Button from './Button';
import { colors } from '../styles/commonStyles';
import { BarCodeScanner } from 'expo-barcode-scanner';

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onScanned: (code: string) => void;
};

export default function BarcodeScannerSheet({ open, onOpenChange, onScanned }: Props) {
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);
  const [scanned, setScanned] = useState(false);
  const [manualCode, setManualCode] = useState('');

  useEffect(() => {
    let mounted = true;
    if (!open) return;
    if (Platform.OS === 'web') {
      setHasPermission(null);
      return;
    }
    (async () => {
      try {
        const { status } = await BarCodeScanner.requestPermissionsAsync();
        if (!mounted) return;
        setHasPermission(status === 'granted');
      } catch (e) {
        console.log('Barcode permission error', e);
        if (!mounted) return;
        setHasPermission(false);
      }
    })();
    return () => {
      mounted = false;
      setScanned(false);
    };
  }, [open]);

  const handleBarCodeScanned = ({ data }: { data: string }) => {
    if (scanned) return;
    setScanned(true);
    console.log('Scanned barcode:', data);
    onScanned(String(data));
  };

  return (
    <BottomSheetModal open={open} onOpenChange={onOpenChange} title="Scan Barcode">
      {Platform.OS === 'web' ? (
        <View style={styles.block}>
          <Text style={styles.muted}>
            Camera scanning may not be available in this preview on web. You can type a barcode manually below.
          </Text>
          <View style={{ height: 12 }} />
          <Text style={styles.label}>Barcode</Text>
          <TextInput
            value={manualCode}
            onChangeText={setManualCode}
            placeholder="e.g., 012345678905"
            placeholderTextColor={colors.textMuted}
            style={styles.input}
            keyboardType="numeric"
          />
          <Button
            text="Add by Code"
            onPress={() => {
              if (!manualCode.trim()) return;
              onScanned(manualCode.trim());
              setManualCode('');
            }}
          />
          <Button
            text="Close"
            onPress={() => onOpenChange(false)}
            style={{ backgroundColor: colors.backgroundAlt, marginTop: 8 }}
            textStyle={{ color: colors.text }}
          />
        </View>
      ) : hasPermission === null ? (
        <View style={styles.block}>
          <Text style={styles.muted}>Requesting camera permissions…</Text>
          <Button
            text="Close"
            onPress={() => onOpenChange(false)}
            style={{ backgroundColor: colors.backgroundAlt, marginTop: 8 }}
            textStyle={{ color: colors.text }}
          />
        </View>
      ) : hasPermission === false ? (
        <View style={styles.block}>
          <Text style={styles.muted}>
            Camera access was denied. Please enable camera permissions in your device settings to scan barcodes.
          </Text>
          <Button
            text="Close"
            onPress={() => onOpenChange(false)}
            style={{ backgroundColor: colors.backgroundAlt, marginTop: 8 }}
            textStyle={{ color: colors.text }}
          />
        </View>
      ) : (
        <View style={styles.block}>
          <View style={styles.scannerContainer}>
            <BarCodeScanner
              onBarCodeScanned={scanned ? undefined : handleBarCodeScanned}
              style={styles.scanner}
            />
            <View style={styles.overlay}>
              <Text style={styles.overlayText}>Align barcode within frame</Text>
            </View>
          </View>
          {scanned ? (
            <Button
              text="Scan Again"
              onPress={() => setScanned(false)}
              style={{ marginTop: 12 }}
            />
          ) : null}
          <View style={{ height: 12 }} />
          <Text style={styles.label}>Or type code</Text>
          <TextInput
            value={manualCode}
            onChangeText={setManualCode}
            placeholder="e.g., 012345678905"
            placeholderTextColor={colors.textMuted}
            style={styles.input}
            keyboardType="numeric"
          />
          <Button
            text="Add by Code"
            onPress={() => {
              if (!manualCode.trim()) return;
              onScanned(manualCode.trim());
              setManualCode('');
            }}
          />
          <Button
            text="Close"
            onPress={() => onOpenChange(false)}
            style={{ backgroundColor: colors.backgroundAlt, marginTop: 8 }}
            textStyle={{ color: colors.text }}
          />
        </View>
      )}
    </BottomSheetModal>
  );
}

const styles = StyleSheet.create({
  block: {
    gap: 8 as any,
  },
  scannerContainer: {
    height: 260,
    borderRadius: 12,
    overflow: 'hidden',
    borderColor: colors.grey,
    borderWidth: 1,
    position: 'relative',
    boxShadow: '0 2px 6px rgba(0,0,0,0.08)',
  },
  scanner: {
    width: '100%',
    height: '100%',
  },
  overlay: {
    position: 'absolute',
    left: 16,
    right: 16,
    top: 16,
    borderColor: '#00FF88',
    borderWidth: 2,
    borderRadius: 8,
    bottom: 16,
    pointerEvents: 'none' as any,
  },
  overlayText: {
    position: 'absolute',
    bottom: 8,
    left: 8,
    right: 8,
    color: '#00FF88',
    fontWeight: '700',
  },
  muted: {
    color: colors.textMuted,
  },
  label: {
    color: colors.text,
    fontWeight: '700',
  },
  input: {
    backgroundColor: colors.backgroundAlt,
    color: colors.text,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderColor: colors.grey,
    borderWidth: 1,
  },
});
