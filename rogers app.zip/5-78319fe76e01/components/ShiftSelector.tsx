
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { colors } from '../styles/commonStyles';

type Props = {
  currentShiftPreset: 'Day' | 'Grave' | '24-on' | 'Off';
  onPresetChange: (preset: 'Day' | 'Grave' | '24-on' | 'Off') => void;
};

const PRESETS: Array<'Day' | 'Grave' | '24-on' | 'Off'> = ['Day', 'Grave', '24-on', 'Off'];

export default function ShiftSelector({ currentShiftPreset, onPresetChange }: Props) {
  return (
    <View style={styles.row}>
      {PRESETS.map((p) => {
        const active = currentShiftPreset === p;
        return (
          <TouchableOpacity
            key={p}
            onPress={() => onPresetChange(p)}
            style={[styles.pill, { backgroundColor: active ? colors.primary : colors.card }]}
          >
            <Text style={[styles.pillText, { color: active ? '#fff' : colors.text }]}>{p}</Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    gap: 8 as any,
    marginBottom: 8,
  },
  pill: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: colors.grey,
    boxShadow: '0 1px 2px rgba(0,0,0,0.06)',
  },
  pillText: {
    fontWeight: '700',
  },
});
