
import React, { createContext, useContext, useMemo, useState } from 'react';
import dayjs from 'dayjs';

// Types
type ShiftType = 'Off' | 'Day' | 'Grave' | '24-on';

type ShiftInfo = {
  type: ShiftType;
  overtime?: boolean;
  travel?: boolean;
  completed?: boolean;
  rpe?: number;
  pain?: boolean;
};

type PlanItem = {
  workout?: { name: string };
  cardio?: string;
  meals?: string[];
};

type NutritionTargets = {
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
};

type NutritionLog = {
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  sodium: number;
  waterMl: number;
  caffeineMg: number;
  dutyMealMode: boolean;
};

type VoiceNote = { durationSec: number; url?: string };

type Message = {
  id: string;
  text: string;
  from: 'client' | 'coach';
  urgent?: boolean;
  system?: boolean;
  timestamp: string;
  voiceNote?: VoiceNote;
};

type Program = {
  id: string;
  name: string;
  daysPerWeek: number;
  split: string;
  exercises: { name: string; alt?: string }[];
};

type AppState = {
  shiftModePreset: ShiftType;
  equipment: { hasBarbell: boolean; hasMachines: boolean };
  shifts: Record<string, ShiftInfo>;
  plan: Record<string, PlanItem>;
  nutritionTargets: NutritionTargets;
  nutritionLogs: Record<string, NutritionLog>;
  officeHours: { start: number; end: number };
  messages: Message[];
  progress: { weightTrend: number[]; liftTrend: number[] };
  kpis: { adherence: number; nutritionCompliance: number };
  flags: string[];
  summary: string;
  currentProgram?: Program;
  goal: 'loss' | 'gain' | 'maintain';
  admin: { billingPlan: 'PIF' | 'Installments'; contracts: Record<string, boolean> };
  progressionMode: 'RPE' | 'PCT1RM';
};

type CheckinPayload = {
  weights: number[];
  avgWeight: number;
  steps: number;
  sleep: number;
  stress: string;
  digestion: string;
  soreness: string;
  adherence: number;
  notes: string;
};

type AppActions = {
  setShiftPreset: (p: ShiftType) => void;
  cycleShift: (date: string) => void;
  toggleOvertime: (date: string) => void;
  toggleTravel: (date: string) => void;
  completeDay: (date: string, rpe?: number, pain?: boolean) => void;
  rescheduleToday: (date: string) => void;

  toggleEquipment: (key: 'hasBarbell' | 'hasMachines') => void;

  setNutritionTargets: (targets: NutritionTargets) => void;
  addCalories: (dateKey: string, amount: number) => void;
  addProtein: (dateKey: string, amount: number) => void;
  addCarbs: (dateKey: string, amount: number) => void;
  addFats: (dateKey: string, amount: number) => void;
  addWater: (dateKey: string, amount: number) => void;
  addSodium: (dateKey: string, amount: number) => void;
  addCaffeine: (dateKey: string, amount: number) => void;
  toggleDutyMealMode: (dateKey: string, v: boolean) => void;
  resetNutrition: (dateKey: string) => void;

  isWithinOfficeHours: () => boolean;
  sendMessage: (msg: Omit<Message, 'id' | 'timestamp'>) => void;
  addVoiceNote: (urgent: boolean) => void;

  submitCheckin: (payload: CheckinPayload) => void;

  assignProgram: (program: Program) => void;
  setProgressionMode: (mode: 'RPE' | 'PCT1RM') => void;
  setBillingPlan: (plan: 'PIF' | 'Installments') => void;
  toggleContract: (name: string) => void;
  setGoal: (g: 'loss' | 'gain' | 'maintain') => void;
};

const defaultState: AppState = {
  shiftModePreset: 'Off',
  equipment: { hasBarbell: true, hasMachines: true },
  shifts: {},
  plan: {},
  nutritionTargets: { calories: 2400, protein: 170, carbs: 250, fats: 70 },
  nutritionLogs: {},
  officeHours: { start: 9, end: 17 },
  messages: [],
  progress: {
    weightTrend: [190, 189.5, 189.8, 189.2, 188.9, 188.7, 188.5],
    liftTrend: [200, 205, 210, 215, 220, 225, 230],
  },
  kpis: { adherence: 0.85, nutritionCompliance: 0.72 },
  flags: [],
  summary: 'Solid week. Weight trending down, lifts stable.',
  goal: 'loss',
  admin: { billingPlan: 'PIF', contracts: { 'PAR-Q': false, 'Liability Waiver': false, 'PED/Medical Referral': false } },
  progressionMode: 'RPE',
};

const AppContext = createContext<{ state: AppState; actions: AppActions } | null>(null);

function ensureLog(state: AppState, dateKey: string): NutritionLog {
  if (!state.nutritionLogs[dateKey]) {
    state.nutritionLogs[dateKey] = {
      calories: 0,
      protein: 0,
      carbs: 0,
      fats: 0,
      sodium: 0,
      waterMl: 0,
      caffeineMg: 0,
      dutyMealMode: false,
    };
  }
  return state.nutritionLogs[dateKey];
}

function getWeekDates(anchor = dayjs()): string[] {
  const start = anchor.startOf('week');
  return Array.from({ length: 7 }).map((_, i) => start.add(i, 'day').format('YYYY-MM-DD'));
}

function recalcDerived(state: AppState): AppState {
  const today = dayjs();
  const weekDays = getWeekDates(today);
  let assigned = 0;
  let completed = 0;
  weekDays.forEach((d) => {
    if (state.plan[d]?.workout) {
      assigned += 1;
      if (state.shifts[d]?.completed) completed += 1;
    }
  });
  const adherence = assigned > 0 ? completed / assigned : state.kpis.adherence;

  // Nutrition compliance: last 7 days within ±100 kcal (derived from macros) and ±10g protein
  let withTargets = 0;
  let goodDays = 0;
  weekDays.forEach((d) => {
    const log = state.nutritionLogs[d];
    if (!log) return;
    withTargets += 1;
    const derivedCalories = log.protein * 4 + log.carbs * 4 + log.fats * 9;
    const cDiff = Math.abs(derivedCalories - state.nutritionTargets.calories);
    const pDiff = Math.abs(log.protein - state.nutritionTargets.protein);
    if (cDiff <= 100 && pDiff <= 10) goodDays += 1;
  });
  const nutritionCompliance = withTargets > 0 ? goodDays / withTargets : state.kpis.nutritionCompliance;

  const flagsSet = new Set<string>();
  if (adherence < 0.7) flagsSet.add('Adherence below 70%');
  if (nutritionCompliance < 0.5) flagsSet.add('Nutrition compliance low');

  // High RPE and pain flags over the last 14 days
  const last14 = Array.from({ length: 14 }).map((_, i) => today.subtract(i, 'day').format('YYYY-MM-DD'));
  const rpeHigh = last14.filter((d) => (state.shifts[d]?.rpe || 0) > 9).length;
  if (rpeHigh >= 3) flagsSet.add('RPE>9 repeatedly');
  const anyPain = last14.some((d) => state.shifts[d]?.pain);
  if (anyPain) flagsSet.add('Pain reported');

  // Weight trend against goal over last 14 trend points
  const wt = state.progress.weightTrend.slice(-14);
  if (wt.length >= 2) {
    const delta = wt[wt.length - 1] - wt[0];
    if (state.goal === 'loss' && delta > 0) flagsSet.add('Weight trend off target >2 weeks');
    if (state.goal === 'gain' && delta < 0) flagsSet.add('Weight trend off target >2 weeks');
  }

  const flags = Array.from(flagsSet);
  const summary = `Adherence ${Math.round(adherence * 100)}%, Nutrition ${Math.round(nutritionCompliance * 100)}%. ${flags.length ? 'Flags: ' + flags.join(', ') : 'No flags.'}`;

  return {
    ...state,
    kpis: { adherence, nutritionCompliance },
    flags,
    summary,
  };
}

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AppState>(() => {
    return recalcDerived({ ...defaultState });
  });

  const actions = useMemo<AppActions>(() => {
    return {
      setShiftPreset: (p) => {
        console.log('setShiftPreset', p);
        setState((prev) => {
          const days = getWeekDates(dayjs());
          const nextShifts: Record<string, ShiftInfo> = { ...prev.shifts };
          const nextPlan: Record<string, PlanItem> = { ...prev.plan };

          const planFor = (t: ShiftType): PlanItem => {
            if (t === 'Off') return { meals: ['Breakfast', 'Lunch', 'Dinner'], cardio: 'Walk 10m' };
            const cardio = t === '24-on' ? 'LISS 15m' : t === 'Grave' ? 'LISS 10m' : 'LISS 20m';
            return { workout: { name: `Shift Session – ${t}` }, cardio, meals: ['Breakfast', 'Lunch', 'Dinner'] };
          };

          days.forEach((d) => {
            nextShifts[d] = { ...(nextShifts[d] || {}), type: p };
            nextPlan[d] = { ...nextPlan[d], ...planFor(p) };
          });

          return recalcDerived({ ...prev, shiftModePreset: p, shifts: nextShifts, plan: nextPlan });
        });
      },
      cycleShift: (date) => {
        console.log('cycleShift', date);
        setState((prev) => {
          const current = prev.shifts[date]?.type ?? 'Off';
          const order: ShiftType[] = ['Off', 'Day', 'Grave', '24-on'];
          const idx = order.indexOf(current);
          const next = order[(idx + 1) % order.length];
          const nextShifts = { ...prev.shifts, [date]: { ...(prev.shifts[date] || {}), type: next } };
          // Adjust plan minimalistically
          const base: PlanItem = { meals: ['Breakfast', 'Lunch', 'Dinner'] };
          let workout: PlanItem['workout'] | undefined;
          let cardio: string | undefined;
          if (next !== 'Off') {
            workout = { name: 'Session - ' + next };
            cardio = next === '24-on' ? 'LISS 15m' : 'LISS 20m';
          }
          const nextPlan = { ...prev.plan, [date]: { ...base, workout, cardio } };
          return recalcDerived({ ...prev, shifts: nextShifts, plan: nextPlan });
        });
      },
      toggleOvertime: (date) => {
        console.log('toggleOvertime', date);
        setState((prev) => {
          const s = prev.shifts[date] || { type: 'Off' as ShiftType };
          const next = { ...s, overtime: !s.overtime };
          const nextShifts = { ...prev.shifts, [date]: next };
          // Adjust plan cardio slightly
          const p = prev.plan[date] || {};
          const cardio = next.overtime ? 'LISS 10m' : p.cardio || 'LISS 20m';
          const nextPlan = { ...prev.plan, [date]: { ...p, cardio } };
          return recalcDerived({ ...prev, shifts: nextShifts, plan: nextPlan });
        });
      },
      toggleTravel: (date) => {
        console.log('toggleTravel', date);
        setState((prev) => {
          const s = prev.shifts[date] || { type: 'Off' as ShiftType };
          const next = { ...s, travel: !s.travel };
          const nextShifts = { ...prev.shifts, [date]: next };
          // If travel, maybe no workout
          const p = prev.plan[date] || {};
          const nextPlan = { ...prev.plan, [date]: { ...p, workout: next.travel ? undefined : p.workout } };
          return recalcDerived({ ...prev, shifts: nextShifts, plan: nextPlan });
        });
      },
      completeDay: (date, rpe, pain) => {
        console.log('completeDay', date, rpe, pain);
        setState((prev) => {
          const s = prev.shifts[date] || { type: 'Off' as ShiftType };
          const nextShifts = { ...prev.shifts, [date]: { ...s, completed: true, rpe, pain } };
          return recalcDerived({ ...prev, shifts: nextShifts });
        });
      },
      rescheduleToday: (date) => {
        console.log('rescheduleToday', date);
        setState((prev) => {
          const todayPlan = prev.plan[date];
          if (!todayPlan || (!todayPlan.workout && !todayPlan.cardio)) return prev;

          // Find next day within the next two weeks that has no workout assigned
          let target = '';
          for (let i = 1; i <= 14; i++) {
            const candidate = dayjs(date).add(i, 'day').format('YYYY-MM-DD');
            const p = prev.plan[candidate];
            if (!p || !p.workout) {
              target = candidate;
              break;
            }
          }
          // If still not found, push to 15th day ahead
          if (!target) target = dayjs(date).add(15, 'day').format('YYYY-MM-DD');

          const moved: PlanItem = { ...todayPlan };
          const nextPlan: Record<string, PlanItem> = {
            ...prev.plan,
            [target]: {
              ...prev.plan[target],
              workout: moved.workout,
              cardio: moved.cardio ?? (prev.shifts[target]?.type === '24-on' ? 'LISS 15m' : 'LISS 20m'),
              meals: moved.meals || ['Breakfast', 'Lunch', 'Dinner'],
            },
            [date]: { meals: ['Quick no-heat'], cardio: 'Walk 10m' },
          };
          return recalcDerived({ ...prev, plan: nextPlan });
        });
      },

      toggleEquipment: (key) => {
        console.log('toggleEquipment', key);
        setState((prev) => recalcDerived({ ...prev, equipment: { ...prev.equipment, [key]: !prev.equipment[key] } }));
      },

      setNutritionTargets: (targets) => {
        console.log('setNutritionTargets', targets);
        setState((prev) => recalcDerived({ ...prev, nutritionTargets: targets }));
      },
      addCalories: (dateKey, amount) => {
        setState((prev) => {
          const copy = { ...prev };
          const log = ensureLog(copy, dateKey);
          log.calories += amount;
          return recalcDerived(copy);
        });
      },
      addProtein: (dateKey, amount) => {
        setState((prev) => {
          const copy = { ...prev };
          const log = ensureLog(copy, dateKey);
          log.protein += amount;
          // 4 kcal per g protein
          log.calories += amount * 4;
          return recalcDerived(copy);
        });
      },
      addWater: (dateKey, amount) => {
        setState((prev) => {
          const copy = { ...prev };
          const log = ensureLog(copy, dateKey);
          log.waterMl += amount;
          return recalcDerived(copy);
        });
      },
      addCarbs: (dateKey, amount) => {
        setState((prev) => {
          const copy = { ...prev };
          const log = ensureLog(copy, dateKey);
          log.carbs += amount;
          // 4 kcal per g carbs
          log.calories += amount * 4;
          return recalcDerived(copy);
        });
      },
      addFats: (dateKey, amount) => {
        setState((prev) => {
          const copy = { ...prev };
          const log = ensureLog(copy, dateKey);
          log.fats += amount;
          // 9 kcal per g fat
          log.calories += amount * 9;
          return recalcDerived(copy);
        });
      },
      addSodium: (dateKey, amount) => {
        setState((prev) => {
          const copy = { ...prev };
          const log = ensureLog(copy, dateKey);
          log.sodium += amount;
          return recalcDerived(copy);
        });
      },
      addCaffeine: (dateKey, amount) => {
        setState((prev) => {
          const copy = { ...prev };
          const log = ensureLog(copy, dateKey);
        log.caffeineMg += amount;
          return recalcDerived(copy);
        });
      },
      toggleDutyMealMode: (dateKey, v) => {
        setState((prev) => {
          const copy = { ...prev } as AppState;
          const log = ensureLog(copy, dateKey);
          log.dutyMealMode = v;
          return recalcDerived(copy);
        });
      },
      resetNutrition: (dateKey) => {
        console.log('resetNutrition', dateKey);
        setState((prev) => {
          const copy = { ...prev };
          copy.nutritionLogs[dateKey] = {
            calories: 0,
            protein: 0,
            carbs: 0,
            fats: 0,
            sodium: 0,
            waterMl: 0,
            caffeineMg: 0,
            dutyMealMode: copy.nutritionLogs[dateKey]?.dutyMealMode ?? false,
          };
          return recalcDerived(copy);
        });
      },

      isWithinOfficeHours: () => {
        const now = dayjs();
        const hour = Number(now.format('H'));
        return hour >= state.officeHours.start && hour < state.officeHours.end;
      },
      sendMessage: (msg) => {
        setState((prev) => {
          const newMsg: Message = {
            id: Math.random().toString(36).slice(2),
            timestamp: new Date().toISOString(),
            ...msg,
          };
          return { ...prev, messages: [...prev.messages, newMsg] };
        });
      },
      addVoiceNote: (urgent) => {
        setState((prev) => {
          const newMsg: Message = {
            id: Math.random().toString(36).slice(2),
            timestamp: new Date().toISOString(),
            from: 'client',
            text: 'Voice note',
            urgent,
            voiceNote: { durationSec: 30 },
          };
          return { ...prev, messages: [...prev.messages, newMsg] };
        });
      },

      submitCheckin: (payload) => {
        console.log('submitCheckin', payload);
        setState((prev) => {
          // Update progress trends simply by appending a point
          const newWeightTrend = [...prev.progress.weightTrend, payload.avgWeight].slice(-14);
          const newLiftTrend = [...prev.progress.liftTrend, prev.progress.liftTrend[prev.progress.liftTrend.length - 1] + 2].slice(-14);

          let flags = [...prev.flags];
          if (payload.adherence < 70) flags = Array.from(new Set([...flags, 'Adherence <70% from check-in']));
          if (payload.sleep < 6) flags = Array.from(new Set([...flags, 'Sleep <6h average']));
          const noteLine = payload.notes ? ` Notes: ${payload.notes.slice(0, 60)}` : '';
          const summary = `Check-in: avg ${payload.avgWeight}lb, steps ${payload.steps}/day.${noteLine}`;

          const next = {
            ...prev,
            progress: { weightTrend: newWeightTrend, liftTrend: newLiftTrend },
            flags,
            summary,
          };
          return recalcDerived(next);
        });
      },

      assignProgram: (program) => {
        console.log('assignProgram', program.name);
        setState((prev) => {
          // Generate a simple weekly plan based on daysPerWeek
          const days = getWeekDates(dayjs());
          const planCopy: Record<string, PlanItem> = { ...prev.plan };
          let assigned = 0;
          days.forEach((d, i) => {
            if (assigned < program.daysPerWeek) {
              planCopy[d] = {
                workout: { name: `${program.name} – Day ${assigned + 1}` },
                cardio: i % 2 === 0 ? 'LISS 20m' : 'None',
                meals: ['Breakfast', 'Lunch', 'Dinner'],
              };
              assigned += 1;
            } else if (!planCopy[d]) {
              planCopy[d] = { meals: ['Breakfast', 'Lunch', 'Dinner'], cardio: 'Walk 10m' };
            }
          });
          return recalcDerived({ ...prev, currentProgram: program, plan: planCopy });
        });
      },
      setProgressionMode: (mode) => {
        setState((prev) => ({ ...prev, progressionMode: mode }));
      },
      setBillingPlan: (plan) => {
        setState((prev) => ({ ...prev, admin: { ...prev.admin, billingPlan: plan } }));
      },
      toggleContract: (name) => {
        setState((prev) => ({
          ...prev,
          admin: {
            ...prev.admin,
            contracts: { ...prev.admin.contracts, [name]: !prev.admin.contracts[name] },
          },
        }));
      },
      setGoal: (g) => {
        setState((prev) => recalcDerived({ ...prev, goal: g }));
      },
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.officeHours.start, state.officeHours.end]);

  const value = useMemo(() => ({ state, actions }), [state, actions]);

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) {
    console.log('useApp called outside AppProvider');
    throw new Error('useApp must be used within an AppProvider');
  }
  return ctx;
}
