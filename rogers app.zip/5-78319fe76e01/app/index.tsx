
import { Redirect } from 'expo-router';

export default function Main() {
  // Immediately route to the main app tabs
  return <Redirect href="/(tabs)/calendar" />;
}
