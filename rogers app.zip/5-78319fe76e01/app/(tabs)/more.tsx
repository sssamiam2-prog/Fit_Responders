
import { View, Text, StyleSheet, ScrollView, Linking, Switch, Alert } from 'react-native';
import { colors } from '../../styles/commonStyles';
import Button from '../../components/Button';
import { useApp } from '../../context/AppContext';
import dayjs from 'dayjs';

export default function MoreScreen() {
  const { state, actions } = useApp();
  const nextCharge = dayjs().add(1, 'month').format('MMM D, YYYY');

  const startAutoBilling = () => {
    Alert.alert(
      'Enable Backend',
      'Auto-billing requires a backend. Please enable Supabase by pressing the Supabase button and connecting a project. Then we will wire Stripe securely.',
      [
        { text: 'OK', style: 'default' },
        { text: 'Stripe Docs', onPress: () => Linking.openURL('https://stripe.com') },
      ]
    );
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.background }} contentContainerStyle={{ padding: 16 }}>
      <Text style={styles.title}>Payments & Admin</Text>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Billing Plan</Text>
        <Text style={styles.muted}>Choose a plan. Auto-billing schedule is simulated until backend is enabled.</Text>
        <View style={{ flexDirection: 'row', gap: 8 as any }}>
          <Button
            text="Paid in Full"
            onPress={() => actions.setBillingPlan('PIF')}
            style={{ flex: 1, backgroundColor: state.admin.billingPlan === 'PIF' ? colors.primary : colors.card }}
            textStyle={{ color: state.admin.billingPlan === 'PIF' ? '#fff' : colors.text }}
          />
          <Button
            text="Installments"
            onPress={() => actions.setBillingPlan('Installments')}
            style={{ flex: 1, backgroundColor: state.admin.billingPlan === 'Installments' ? colors.primary : colors.card }}
            textStyle={{ color: state.admin.billingPlan === 'Installments' ? '#fff' : colors.text }}
          />
        </View>
        <View style={styles.row}>
          <Text style={styles.muted}>Next charge date (mock):</Text>
          <Text style={styles.value}>{nextCharge}</Text>
        </View>
        <Button text="Start Auto-Billing" onPress={startAutoBilling} />
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Contracts / E‑Sign</Text>
        {Object.keys(state.admin.contracts).map((name) => {
          const checked = state.admin.contracts[name];
          return (
            <View key={name} style={styles.contractRow}>
              <Text style={styles.contractText}>{name}</Text>
              <Switch value={checked} onValueChange={() => actions.toggleContract(name)} />
            </View>
          );
        })}
        <Text style={styles.muted}>E‑sign and storage require backend. We&apos;ll sync signatures once Supabase is connected.</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Integrations</Text>
        <Text style={styles.muted}>
          Apple/Google Health, Garmin/Whoop/Oura syncs require device APIs and backend processing. Manual logging and CSV export are available meanwhile.
        </Text>
        <Button text="Export (CSV mock)" onPress={() => { console.log('Export tapped'); }} />
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Maps</Text>
        <Text style={styles.muted}>
          react-native-maps is not supported on web in Natively. We show this notice instead of a map.
        </Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Content Hub</Text>
        <Text style={styles.muted}>
          Add shift-meal videos, grocery lists, and station-kitchen guides here. We will connect once assets are ready.
        </Text>
        <Button text="Learn about Stripe" onPress={() => Linking.openURL('https://stripe.com')} />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  title: {
    color: colors.text,
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 8,
  },
  card: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 12,
    marginBottom: 12,
    boxShadow: '0 2px 6px rgba(0,0,0,0.08)',
  },
  cardTitle: {
    color: colors.text,
    fontWeight: '800',
    marginBottom: 6,
  },
  muted: {
    color: colors.textMuted,
    marginBottom: 8,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginVertical: 8,
  },
  value: {
    color: colors.text,
    fontWeight: '700',
  },
  contractRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 6,
  },
  contractText: {
    color: colors.text,
    fontWeight: '600',
  },
});
