
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { colors, commonStyles } from '../../styles/commonStyles';
import { useApp } from '../../context/AppContext';
import DoughnutChart from '../../components/DoughnutChart';

export default function DashboardScreen() {
  const { state } = useApp();

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.background }} contentContainerStyle={{ padding: 16 }}>
      <Text style={styles.title}>Coach Dashboard</Text>

      <View style={styles.cardRow}>
        <View style={styles.card}>
          <DoughnutChart size={110} strokeWidth={14} progress={state.kpis.adherence} color={colors.primary} />
          <Text style={styles.cardTitle}>Adherence</Text>
          <Text style={styles.cardValue}>{Math.round(state.kpis.adherence * 100)}%</Text>
        </View>
        <View style={styles.card}>
          <DoughnutChart size={110} strokeWidth={14} progress={state.kpis.nutritionCompliance} color={colors.secondary} />
          <Text style={styles.cardTitle}>Nutrition</Text>
          <Text style={styles.cardValue}>{Math.round(state.kpis.nutritionCompliance * 100)}%</Text>
        </View>
      </View>

      <View style={styles.card}>
        <Text style={styles.sectionTitle}>Flags</Text>
        {state.flags.length === 0 ? (
          <Text style={styles.muted}>No flags 🎉</Text>
        ) : (
          state.flags.map((f) => (
            <View key={f} style={styles.flag}>
              <Text style={styles.flagText}>⚑ {f}</Text>
            </View>
          ))
        )}
      </View>

      <View style={styles.card}>
        <Text style={styles.sectionTitle}>Summary</Text>
        <Text style={styles.muted}>{state.summary}</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  title: {
    color: colors.text,
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 8,
  },
  cardRow: {
    flexDirection: 'row',
    gap: 12 as any,
    marginBottom: 12,
  },
  card: {
    flex: 1,
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 12,
    alignItems: 'center',
    boxShadow: '0 2px 6px rgba(0,0,0,0.08)',
    marginBottom: 12,
  },
  cardTitle: {
    color: colors.text,
    fontWeight: '700',
    marginTop: 8,
  },
  cardValue: {
    color: colors.text,
    marginBottom: 8,
  },
  sectionTitle: {
    alignSelf: 'flex-start',
    color: colors.text,
    fontWeight: '800',
    marginBottom: 8,
  },
  muted: {
    color: colors.textMuted,
  },
  flag: {
    backgroundColor: colors.backgroundAlt,
    borderRadius: 8,
    padding: 8,
    marginBottom: 6,
    borderColor: colors.grey,
    borderWidth: 1,
    alignSelf: 'stretch',
  },
  flagText: {
    color: colors.text,
    fontWeight: '600',
  },
});
