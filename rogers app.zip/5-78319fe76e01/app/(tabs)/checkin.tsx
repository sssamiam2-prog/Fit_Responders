
import { useMemo, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TextInput } from 'react-native';
import { colors } from '../../styles/commonStyles';
import Button from '../../components/Button';
import { useApp } from '../../context/AppContext';

export default function CheckinScreen() {
  const { state, actions } = useApp();
  const [weights, setWeights] = useState<string[]>(Array(7).fill(''));
  const [steps, setSteps] = useState('');
  const [sleep, setSleep] = useState('');
  const [stress, setStress] = useState('');
  const [digestion, setDigestion] = useState('');
  const [soreness, setSoreness] = useState('');
  const [adherence, setAdherence] = useState('');
  const [notes, setNotes] = useState('');

  const avg = useMemo(() => {
    const nums = weights.map((w) => Number(w)).filter((n) => !isNaN(n) && n > 0);
    if (!nums.length) return 0;
    return Math.round((nums.reduce((a, b) => a + b, 0) / nums.length) * 10) / 10;
  }, [weights]);

  const submit = () => {
    actions.submitCheckin({
      weights: weights.map((w) => Number(w) || 0),
      avgWeight: avg,
      steps: Number(steps) || 0,
      sleep: Number(sleep) || 0,
      stress,
      digestion,
      soreness,
      adherence: Number(adherence) || 0,
      notes,
    });
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.background }} contentContainerStyle={{ padding: 16 }}>
      <Text style={styles.title}>Weekly Check-In</Text>
      <Text style={styles.label}>Weight (7-day)</Text>
      <View style={styles.row}>
        {weights.map((v, i) => (
          <TextInput
            key={i}
            value={v}
            onChangeText={(t) => setWeights((prev) => prev.map((p, idx) => (idx === i ? t : p)))}
            keyboardType="numeric"
            placeholder={`D${i + 1}`}
            placeholderTextColor={colors.textMuted}
            style={styles.inputSmall}
          />
        ))}
      </View>
      <Text style={styles.muted}>7-day average: {avg || 0}</Text>

      <View style={styles.grid}>
        <View style={styles.cell}>
          <Text style={styles.label}>Steps/day</Text>
          <TextInput value={steps} onChangeText={setSteps} keyboardType="numeric" style={styles.input} />
        </View>
        <View style={styles.cell}>
          <Text style={styles.label}>Sleep (h)</Text>
          <TextInput value={sleep} onChangeText={setSleep} keyboardType="numeric" style={styles.input} />
        </View>
      </View>

      <View style={styles.grid}>
        <View style={styles.cell}>
          <Text style={styles.label}>Stress</Text>
          <TextInput value={stress} onChangeText={setStress} style={styles.input} placeholder="low/med/high" placeholderTextColor={colors.textMuted} />
        </View>
        <View style={styles.cell}>
          <Text style={styles.label}>Digestion</Text>
          <TextInput value={digestion} onChangeText={setDigestion} style={styles.input} placeholder="good/ok/poor" placeholderTextColor={colors.textMuted} />
        </View>
      </View>

      <View style={styles.grid}>
        <View style={styles.cell}>
          <Text style={styles.label}>Soreness</Text>
          <TextInput value={soreness} onChangeText={setSoreness} style={styles.input} placeholder="RPE style 1–10" placeholderTextColor={colors.textMuted} />
        </View>
        <View style={styles.cell}>
          <Text style={styles.label}>Adherence (%)</Text>
          <TextInput value={adherence} onChangeText={setAdherence} keyboardType="numeric" style={styles.input} />
        </View>
      </View>

      <Text style={styles.label}>Notes</Text>
      <TextInput
        value={notes}
        onChangeText={setNotes}
        multiline
        placeholder="Anything else?"
        placeholderTextColor={colors.textMuted}
        style={[styles.input, { height: 100 }]}
      />

      <Button text="Submit Check-In" onPress={submit} />
      <Text style={[styles.muted, { marginTop: 8 }]}>An auto-summary and trend graph will be prepared for you.</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  title: {
    color: colors.text,
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 8,
  },
  label: {
    color: colors.text,
    fontWeight: '700',
    marginBottom: 6,
  },
  row: {
    flexDirection: 'row',
    gap: 6 as any,
    marginBottom: 6,
  },
  inputSmall: {
    flex: 1,
    backgroundColor: colors.card,
    color: colors.text,
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 10,
    borderColor: colors.grey,
    borderWidth: 1,
  },
  grid: {
    flexDirection: 'row',
    gap: 12 as any,
    marginBottom: 8,
  },
  cell: {
    flex: 1,
  },
  input: {
    backgroundColor: colors.card,
    color: colors.text,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderColor: colors.grey,
    borderWidth: 1,
  },
  muted: {
    color: colors.textMuted,
  },
});
