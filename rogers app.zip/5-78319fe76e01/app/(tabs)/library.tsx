
import { useRef, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Image, Dimensions, PanResponder } from 'react-native';
import { colors, commonStyles } from '../../styles/commonStyles';
import Button from '../../components/Button';
import * as ImagePicker from 'expo-image-picker';
import Svg, { Path, Image as SvgImage } from 'react-native-svg';
import { WebView } from 'react-native-webview';

type Stroke = { d: string; color: string; width: number };

const EXERCISES: Array<{ name: string; youtube: string; cue: string }> = [
  { name: 'Squat', youtube: 'https://www.youtube.com/embed/YaXPRqUwItQ', cue: 'Heels down, brace, exhale.' },
  { name: 'Bench Press', youtube: 'https://www.youtube.com/embed/gRVjAtPip0Y', cue: 'Scap retracted, soft lockout.' },
  { name: 'Deadlift', youtube: 'https://www.youtube.com/embed/op9kVnSso6Q', cue: 'Lats tight, push floor, exhale at lockout.' },
];

export default function LibraryScreen() {
  const [picked, setPicked] = useState<string | null>(null);
  const [strokes, setStrokes] = useState<Stroke[]>([]);
  const [color, setColor] = useState('#FF3B30');
  const [width, setWidth] = useState(4);
  const [selectedExercise, setSelectedExercise] = useState(EXERCISES[0]);

  const panPath = useRef('');
  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => !!picked,
      onPanResponderGrant: (evt) => {
        const { locationX, locationY } = evt.nativeEvent;
        panPath.current = `M${locationX},${locationY}`;
      },
      onPanResponderMove: (evt) => {
        const { locationX, locationY } = evt.nativeEvent;
        panPath.current += ` L${locationX},${locationY}`;
      },
      onPanResponderRelease: () => {
        if (panPath.current) {
          setStrokes((prev) => [...prev, { d: panPath.current, color, width }]);
          panPath.current = '';
        }
      },
    })
  ).current;

  const pickImage = async () => {
    const res = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: false,
      quality: 0.8,
    });
    if (!res.canceled && res.assets?.length) {
      setPicked(res.assets[0].uri);
      setStrokes([]);
    }
  };

  const { width: screenW } = Dimensions.get('window');
  const canvasW = Math.min(340, screenW - 32);
  const canvasH = 220;

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.background }} contentContainerStyle={{ padding: 16 }}>
      <Text style={styles.title}>Exercise Library + Form Check</Text>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 8 }}>
        {EXERCISES.map((e) => (
          <Button
            key={e.name}
            text={e.name}
            onPress={() => setSelectedExercise(e)}
            style={{ marginRight: 8, backgroundColor: selectedExercise.name === e.name ? colors.primary : colors.card }}
            textStyle={{ color: selectedExercise.name === e.name ? '#fff' : colors.text }}
          />
        ))}
      </ScrollView>

      <View style={styles.card}>
        <Text style={styles.sectionTitle}>{selectedExercise.name}</Text>
        <Text style={styles.muted}>{selectedExercise.cue}</Text>
        <View style={{ height: 200, borderRadius: 12, overflow: 'hidden', marginTop: 8, backgroundColor: colors.backgroundAlt }}>
          <WebView
            style={{ flex: 1, backgroundColor: colors.backgroundAlt }}
            source={{ html: `<html><body style="margin:0"><iframe width="100%" height="100%" src="${selectedExercise.youtube}" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></body></html>` }}
          />
        </View>
      </View>

      <View style={styles.card}>
        <Text style={styles.sectionTitle}>Upload a Set — Annotate</Text>
        <Text style={styles.muted}>Pick an image to draw over it. Video annotation/voice-over coming next.</Text>
        <Button text="Pick Image" onPress={pickImage} />
        {picked && (
          <View style={{ marginTop: 8 }}>
            <View style={{ flexDirection: 'row', gap: 8 as any }}>
              <Button text="Red" onPress={() => setColor('#FF3B30')} style={{ flex: 1, backgroundColor: '#FF3B30' }} />
              <Button text="Green" onPress={() => setColor('#34C759')} style={{ flex: 1, backgroundColor: '#34C759' }} />
              <Button text="Blue" onPress={() => setColor('#0F62FE')} style={{ flex: 1, backgroundColor: '#0F62FE' }} />
            </View>
            <View {...panResponder.panHandlers} style={{ marginTop: 8, alignItems: 'center' }}>
              <Svg width={canvasW} height={canvasH}>
                <SvgImage href={{ uri: picked }} x="0" y="0" width={canvasW} height={canvasH} preserveAspectRatio="xMidYMid slice" />
                {strokes.map((s, i) => (
                  <Path key={i} d={s.d} stroke={s.color} strokeWidth={s.width} fill="none" strokeLinecap="round" />
                ))}
              </Svg>
            </View>
            <View style={{ flexDirection: 'row', gap: 8 as any, marginTop: 8 }}>
              <Button text="Undo" onPress={() => strokes.length && setStrokes(strokes.slice(0, -1))} style={{ flex: 1 }} />
              <Button text="Clear" onPress={() => setStrokes([])} style={{ flex: 1 }} />
            </View>
          </View>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  title: {
    color: colors.text,
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 8,
  },
  card: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 12,
    marginBottom: 12,
    boxShadow: '0 2px 6px rgba(0,0,0,0.08)',
  },
  sectionTitle: {
    color: colors.text,
    fontWeight: '800',
    marginBottom: 4,
  },
  muted: {
    color: colors.textMuted,
  },
});
