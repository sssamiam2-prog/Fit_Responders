
import { useMemo, useState } from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { colors, commonStyles } from '../../styles/commonStyles';
import { useApp } from '../../context/AppContext';
import ProgramCard from '../../components/ProgramCard';
import Button from '../../components/Button';
import { samplePrograms } from '../../data/programs';

export default function ProgramsScreen() {
  const { state, actions } = useApp();
  const [selectedPhase, setSelectedPhase] = useState<'PPL' | 'Upper-Lower' | 'Mini Cut' | 'Show Prep'>('PPL');

  const programs = useMemo(() => {
    return samplePrograms[selectedPhase];
  }, [selectedPhase]);

  return (
    <View style={[commonStyles.container, { padding: 16, justifyContent: 'flex-start' }]}>
      <Text style={styles.title}>Programs & Templates</Text>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginVertical: 8 }}>
        {(['PPL', 'Upper-Lower', 'Mini Cut', 'Show Prep'] as const).map((p) => (
          <Button
            key={p}
            text={p}
            onPress={() => setSelectedPhase(p)}
            style={{
              backgroundColor: selectedPhase === p ? colors.primary : colors.card,
              marginRight: 8,
              paddingVertical: 10,
            }}
            textStyle={{ color: selectedPhase === p ? '#fff' : colors.text }}
          />
        ))}
      </ScrollView>

      <ScrollView contentContainerStyle={{ paddingBottom: 48 }}>
        {programs.map((prog) => (
          <ProgramCard
            key={prog.id}
            program={prog}
            hasBarbell={state.equipment.hasBarbell}
            onAssign={(p) => actions.assignProgram(p)}
          />
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  title: {
    color: colors.text,
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 8,
  },
});
