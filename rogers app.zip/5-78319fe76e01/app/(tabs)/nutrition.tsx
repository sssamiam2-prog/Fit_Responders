
import { useMemo, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TextInput, Switch, Alert, TouchableOpacity } from 'react-native';
import { colors } from '../../styles/commonStyles';
import Button from '../../components/Button';
import { useApp } from '../../context/AppContext';
import DoughnutChart from '../../components/DoughnutChart';
import BarcodeScannerSheet from '../../components/BarcodeScannerSheet';

type Food = { name: string; calories: number; protein: number; carbs: number; fats: number };

// Simple offline mock mapping for demo; replace/extend as needed
const BARCODE_DB: Record<string, Food> = {
  // EAN-13 examples (not real foods)
  '012345678905': { name: 'Greek Yogurt 150g', calories: 120, protein: 15, carbs: 10, fats: 0 },
  '978020137962': { name: 'Chicken Breast 4oz', calories: 180, protein: 32, carbs: 0, fats: 4 },
  '4006381333931': { name: 'Oats 50g', calories: 190, protein: 7, carbs: 32, fats: 4 },
  '036000291452': { name: 'Protein Bar', calories: 210, protein: 20, carbs: 24, fats: 7 },
};

const COMMON_FOODS: Food[] = [
  { name: 'Eggs (2)', calories: 140, protein: 12, carbs: 1, fats: 10 },
  { name: 'Banana (medium)', calories: 105, protein: 1, carbs: 27, fats: 0 },
  { name: 'Chicken Breast 4oz', calories: 180, protein: 32, carbs: 0, fats: 4 },
  { name: 'Rice 1 cup cooked', calories: 200, protein: 4, carbs: 44, fats: 0 },
  { name: 'Protein Shake (1 scoop)', calories: 130, protein: 24, carbs: 3, fats: 2 },
  { name: 'Greek Yogurt 150g', calories: 120, protein: 15, carbs: 10, fats: 0 },
  { name: 'Oats 50g', calories: 190, protein: 7, carbs: 32, fats: 4 },
  { name: 'Almonds 28g', calories: 170, protein: 6, carbs: 6, fats: 15 },
];

export default function NutritionScreen() {
  const { state, actions } = useApp();
  const [cal, setCal] = useState(String(state.nutritionTargets.calories));
  const [protein, setProtein] = useState(String(state.nutritionTargets.protein));
  const [carbs, setCarbs] = useState(String(state.nutritionTargets.carbs));
  const [fats, setFats] = useState(String(state.nutritionTargets.fats));
  const [scannerOpen, setScannerOpen] = useState(false);
  const [lastLogged, setLastLogged] = useState<Food | null>(null);
  const [query, setQuery] = useState('');

  const today = new Date();
  const dateKey = today.toISOString().slice(0, 10);
  const todayLog = state.nutritionLogs[dateKey] || {
    calories: 0,
    protein: 0,
    carbs: 0,
    fats: 0,
    sodium: 0,
    waterMl: 0,
    caffeineMg: 0,
    dutyMealMode: false,
  };

  const derivedCalories = todayLog.protein * 4 + todayLog.carbs * 4 + todayLog.fats * 9;

  const calPct = Math.min(1, derivedCalories / Math.max(1, state.nutritionTargets.calories));
  const proPct = Math.min(1, todayLog.protein / Math.max(1, state.nutritionTargets.protein));
  const carbPct = Math.min(1, todayLog.carbs / Math.max(1, state.nutritionTargets.carbs));
  const fatPct = Math.min(1, todayLog.fats / Math.max(1, state.nutritionTargets.fats));

  const handleBarcode = (code: string) => {
    const clean = code.replace(/\s+/g, '');
    const food = BARCODE_DB[clean];
    if (!food) {
      Alert.alert('Not found', 'This barcode is not in the demo database. Try another or add manually.');
      return;
    }
    // Log macros; calories auto-derive from macros
    actions.addProtein(dateKey, food.protein);
    actions.addCarbs(dateKey, food.carbs);
    actions.addFats(dateKey, food.fats);
    setLastLogged(food);
    setScannerOpen(false);
  };

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return COMMON_FOODS;
    return COMMON_FOODS.filter((f) => f.name.toLowerCase().includes(q));
  }, [query]);

  const quickAdd = (f: Food) => {
    // Prefer logging via macros; AppContext derives calories
    actions.addProtein(dateKey, f.protein);
    actions.addCarbs(dateKey, f.carbs);
    actions.addFats(dateKey, f.fats);
    setLastLogged(f);
  };

  return (
    <>
      <ScrollView style={{ flex: 1, backgroundColor: colors.background }} contentContainerStyle={{ padding: 16 }}>
        <Text style={styles.title}>Nutrition</Text>

        <View style={styles.cardWrap}>
          <View style={styles.card}>
            <DoughnutChart size={100} strokeWidth={12} progress={calPct} color={colors.primary} />
            <Text style={styles.cardTitle}>Calories</Text>
            <Text style={styles.cardValue}>{derivedCalories} / {state.nutritionTargets.calories}</Text>
            <Text style={styles.smallMuted}>from macros</Text>
          </View>
          <View style={styles.card}>
            <DoughnutChart size={100} strokeWidth={12} progress={proPct} color={colors.secondary} />
            <Text style={styles.cardTitle}>Protein</Text>
            <Text style={styles.cardValue}>{todayLog.protein}g / {state.nutritionTargets.protein}g</Text>
            <Button text="+20g" onPress={() => actions.addProtein(dateKey, 20)} />
          </View>
          <View style={styles.card}>
            <DoughnutChart size={100} strokeWidth={12} progress={carbPct} color={colors.accent} />
            <Text style={styles.cardTitle}>Carbs</Text>
            <Text style={styles.cardValue}>{todayLog.carbs}g / {state.nutritionTargets.carbs}g</Text>
            <Button text="+25g" onPress={() => actions.addCarbs(dateKey, 25)} />
          </View>
          <View style={styles.card}>
            <DoughnutChart size={100} strokeWidth={12} progress={fatPct} color="#8B5CF6" />
            <Text style={styles.cardTitle}>Fats</Text>
            <Text style={styles.cardValue}>{todayLog.fats}g / {state.nutritionTargets.fats}g</Text>
            <Button text="+10g" onPress={() => actions.addFats(dateKey, 10)} />
          </View>
        </View>

        <View style={[styles.row, { alignItems: 'center' }]}>
          <View style={[styles.smallCard, { flex: 1 }]}>
            <Text style={styles.smallLabel}>Water</Text>
            <Text style={styles.smallValue}>{todayLog.waterMl} ml</Text>
            <Button text="+250ml" onPress={() => actions.addWater(dateKey, 250)} />
          </View>
          <View style={[styles.smallCard, { flex: 1 }]}>
            <Text style={styles.smallLabel}>Sodium</Text>
            <Text style={styles.smallValue}>{todayLog.sodium} mg</Text>
            <Button text="+200mg" onPress={() => actions.addSodium(dateKey, 200)} />
          </View>
          <View style={[styles.smallCard, { flex: 1 }]}>
            <Text style={styles.smallLabel}>Caffeine</Text>
            <Text style={styles.smallValue}>{todayLog.caffeineMg} mg</Text>
            <Button text="+80mg" onPress={() => actions.addCaffeine(dateKey, 80)} />
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Targets</Text>
          <View style={styles.targets}>
            <View style={{ flex: 1 }}>
              <Text style={styles.inputLabel}>Calories</Text>
              <TextInput
                value={cal}
                onChangeText={setCal}
                keyboardType="numeric"
                style={styles.input}
                placeholder="Calories"
                placeholderTextColor={colors.textMuted}
              />
            </View>
            <View style={{ width: 12 }} />
            <View style={{ flex: 1 }}>
              <Text style={styles.inputLabel}>Protein (g)</Text>
              <TextInput
                value={protein}
                onChangeText={setProtein}
                keyboardType="numeric"
                style={styles.input}
                placeholder="Protein"
                placeholderTextColor={colors.textMuted}
              />
            </View>
          </View>
          <View style={styles.targets}>
            <View style={{ flex: 1 }}>
              <Text style={styles.inputLabel}>Carbs (g)</Text>
              <TextInput
                value={carbs}
                onChangeText={setCarbs}
                keyboardType="numeric"
                style={styles.input}
                placeholder="Carbs"
                placeholderTextColor={colors.textMuted}
              />
            </View>
            <View style={{ width: 12 }} />
            <View style={{ flex: 1 }}>
              <Text style={styles.inputLabel}>Fats (g)</Text>
              <TextInput
                value={fats}
                onChangeText={setFats}
                keyboardType="numeric"
                style={styles.input}
                placeholder="Fats"
                placeholderTextColor={colors.textMuted}
              />
            </View>
          </View>
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <Button
              text="Save Targets"
              onPress={() =>
                actions.setNutritionTargets({
                  calories: Number(cal) || 0,
                  protein: Number(protein) || 0,
                  carbs: Number(carbs) || 0,
                  fats: Number(fats) || 0,
                })
              }
              style={{ flex: 1 }}
            />
            <Button
              text="Reset Today"
              onPress={() => actions.resetNutrition(dateKey)}
              style={{ flex: 1, backgroundColor: colors.backgroundAlt }}
              textStyle={{ color: colors.text }}
            />
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Duty-friendly meals</Text>
          <View style={styles.row}>
            <Text style={styles.inputLabel}>I&apos;m on duty (no-heat meals)</Text>
            <Switch value={todayLog.dutyMealMode} onValueChange={(v) => actions.toggleDutyMealMode(dateKey, v)} />
          </View>
          <Text style={styles.smallMuted}>
            Duty mode shows quick no-heat options (rotisserie-based, cooler-friendly).
          </Text>
          <View style={styles.mealChips}>
            {(todayLog.dutyMealMode ? ['Rotisserie Wrap', 'Greek Yogurt + Berries', 'Tuna Pack + Crackers'] : ['Chicken & Rice', 'Beef Bowl', 'Oats & Whey']).map((m) => (
              <View key={m} style={styles.mealChip}><Text style={styles.mealChipText}>{m}</Text></View>
            ))}
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Quick Add (Common Foods)</Text>
          <TextInput
            value={query}
            onChangeText={setQuery}
            placeholder="Search foods"
            placeholderTextColor={colors.textMuted}
            style={[styles.input, { marginBottom: 8 }]}
          />
        <View style={styles.foodList}>
            {filtered.map((f) => (
              <TouchableOpacity key={f.name} style={styles.foodItem} onPress={() => quickAdd(f)}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.foodName}>{f.name}</Text>
                  <Text style={styles.smallMuted}>{f.calories} kcal • {f.protein}g P • {f.carbs}g C • {f.fats}g F</Text>
                </View>
                <Text style={styles.addBtn}>Add</Text>
              </TouchableOpacity>
            ))}
          </View>
          <Text style={[styles.smallMuted, { marginTop: 6 }]}>Tap any item to add it to today&apos;s log.</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Barcode Scan</Text>
          {lastLogged ? (
            <Text style={styles.success}>
              Added {lastLogged.name}: +{lastLogged.protein}g P, +{lastLogged.carbs}g C, +{lastLogged.fats}g F
            </Text>
          ) : (
            <Text style={styles.smallMuted}>Scan a barcode to quickly log foods.</Text>
          )}
          <Button text="Scan Barcode" onPress={() => setScannerOpen(true)} />
        </View>
      </ScrollView>

      <BarcodeScannerSheet
        open={scannerOpen}
        onOpenChange={setScannerOpen}
        onScanned={handleBarcode}
      />
    </>
  );
}

const styles = StyleSheet.create({
  title: {
    color: colors.text,
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 8,
  },
  cardWrap: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12 as any,
    marginBottom: 12,
  },
  card: {
    width: '48%',
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 12,
    alignItems: 'center',
    boxShadow: '0 2px 6px rgba(0,0,0,0.08)',
  },
  cardTitle: {
    color: colors.text,
    fontWeight: '700',
    marginTop: 8,
  },
  cardValue: {
    color: colors.text,
    marginBottom: 4,
  },
  row: {
    flexDirection: 'row',
    gap: 12 as any,
    marginBottom: 12,
  },
  smallCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 12,
    alignItems: 'center',
    boxShadow: '0 2px 6px rgba(0,0,0,0.08)',
  },
  smallLabel: {
    color: colors.text,
    fontWeight: '700',
  },
  smallValue: {
    color: colors.text,
    marginBottom: 8,
  },
  section: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 12,
    marginTop: 8,
    boxShadow: '0 2px 6px rgba(0,0,0,0.08)',
  },
  sectionTitle: {
    color: colors.text,
    fontWeight: '800',
    marginBottom: 8,
  },
  smallMuted: {
    color: colors.textMuted,
  },
  success: {
    color: colors.accent,
    fontWeight: '700',
    marginBottom: 8,
  },
  targets: {
    flexDirection: 'row',
    gap: 12 as any,
    marginBottom: 8,
  },
  inputLabel: {
    color: colors.text,
    fontWeight: '600',
    marginBottom: 6,
  },
  input: {
    backgroundColor: colors.backgroundAlt,
    color: colors.text,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderColor: colors.grey,
    borderWidth: 1,
  },
  mealChips: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8 as any,
    marginTop: 8,
  },
  mealChip: {
    backgroundColor: colors.backgroundAlt,
    borderRadius: 16,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderColor: colors.grey,
    borderWidth: 1,
  },
  mealChipText: {
    color: colors.text,
    fontWeight: '600',
  },
  foodList: {
    gap: 6 as any,
  },
  foodItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.backgroundAlt,
    borderRadius: 10,
    padding: 10,
    borderColor: colors.grey,
    borderWidth: 1,
  },
  foodName: {
    color: colors.text,
    fontWeight: '700',
  },
  addBtn: {
    color: colors.primary,
    fontWeight: '800',
  },
});
