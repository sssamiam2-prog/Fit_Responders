
import { useMemo, useState } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import dayjs from 'dayjs';
import { colors, commonStyles } from '../../styles/commonStyles';
import { useApp } from '../../context/AppContext';
import Button from '../../components/Button';
import ShiftSelector from '../../components/ShiftSelector';
import BottomSheetModal from '../../components/BottomSheetModal';

type DayInfo = {
  date: string;
  label: string;
};

const getWeek = (anchor = dayjs()) => {
  const start = anchor.startOf('week'); // Sunday
  return Array.from({ length: 7 }).map((_, i) => {
    const d = start.add(i, 'day');
    return {
      date: d.format('YYYY-MM-DD'),
      label: d.format('ddd D'),
    } as DayInfo;
  });
};

export default function CalendarScreen() {
  const { state, actions } = useApp();
  const [anchor, setAnchor] = useState(dayjs());
  const week = useMemo(() => getWeek(anchor), [anchor]);
  const [sheetOpen, setSheetOpen] = useState(false);

  const today = dayjs().format('YYYY-MM-DD');

  const onRescheduleToday = () => {
    actions.rescheduleToday(today);
    Alert.alert('Rescheduled', 'Today\'s session has been moved and your week has been reflowed.');
  };

  const changeWeek = (dir: -1 | 1) => {
    setAnchor((prev) => prev.add(dir, 'week'));
  };

  return (
    <View style={[commonStyles.container, { padding: 16, justifyContent: 'flex-start' }]}>
      <View style={styles.headerRow}>
        <TouchableOpacity onPress={() => changeWeek(-1)} style={styles.navButton} accessibilityRole="button">
          <Text style={styles.navText}>{'<'}</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>{anchor.format('MMMM YYYY')}</Text>
        <TouchableOpacity onPress={() => changeWeek(1)} style={styles.navButton} accessibilityRole="button">
          <Text style={styles.navText}>{'>'}</Text>
        </TouchableOpacity>
      </View>

      <ShiftSelector
        currentShiftPreset={state.shiftModePreset}
        onPresetChange={(preset) => actions.setShiftPreset(preset)}
      />

      <View style={styles.quickActions}>
        <Button text="Had a call — reschedule today" onPress={onRescheduleToday} />
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: 24 }}>
        {week.map((d) => {
          const shift = state.shifts[d.date];
          const plan = state.plan[d.date];

          return (
            <View key={d.date} style={styles.dayCard}>
              <View style={styles.dayHeader}>
                <Text style={styles.dayTitle}>{d.label}</Text>
                <TouchableOpacity onPress={() => actions.cycleShift(d.date)} style={styles.shiftPill} accessibilityRole="button">
                  <Text style={styles.shiftPillText}>
                    {shift?.type || 'Off'}{shift?.overtime ? ' + OT' : ''}{shift?.travel ? ' + Travel' : ''}
                  </Text>
                </TouchableOpacity>
              </View>

              <View style={styles.section}>
                <Text style={styles.sectionTitle}>Workout</Text>
                {plan?.workout ? (
                  <Text style={styles.bodyText}>{plan.workout.name}</Text>
                ) : (
                  <Text style={styles.mutedText}>Rest or Cardio</Text>
                )}
              </View>

              <View style={styles.section}>
                <Text style={styles.sectionTitle}>Cardio</Text>
                {plan?.cardio ? (
                  <Text style={styles.bodyText}>{plan.cardio}</Text>
                ) : (
                  <Text style={styles.mutedText}>None</Text>
                )}
              </View>

              <View style={styles.section}>
                <Text style={styles.sectionTitle}>Meals</Text>
                <Text style={styles.bodyText}>
                  {plan?.meals?.join(', ') || 'Standard presets adjusted to shift'}
                </Text>
              </View>

              <View style={{ flexDirection: 'row', gap: 8, marginTop: 8 }}>
                <Button
                  text="Complete"
                  onPress={() => actions.completeDay(d.date)}
                  style={{ flex: 1, backgroundColor: colors.primary }}
                />
                <Button
                  text="Adjust"
                  onPress={() => {
                    actions.toggleOvertime(d.date);
                    actions.toggleTravel(d.date);
                  }}
                  style={{ flex: 1, backgroundColor: colors.secondary }}
                />
              </View>
            </View>
          );
        })}
      </ScrollView>

      <BottomSheetModal
        open={sheetOpen}
        onOpenChange={setSheetOpen}
        title="Settings"
      >
        <View style={{ gap: 8 }}>
          <Text style={styles.sectionTitle}>Equipment Access</Text>
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <Button
              text={state.equipment.hasBarbell ? 'Barbell: Yes' : 'Barbell: No'}
              onPress={() => actions.toggleEquipment('hasBarbell')}
              style={{ flex: 1 }}
            />
            <Button
              text={state.equipment.hasMachines ? 'Machines: Yes' : 'Machines: No'}
              onPress={() => actions.toggleEquipment('hasMachines')}
              style={{ flex: 1 }}
            />
          </View>

          <Text style={[styles.sectionTitle, { marginTop: 8 }]}>Progression</Text>
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <Button
              text="RPE/RIR"
              onPress={() => actions.setProgressionMode('RPE')}
              style={{ flex: 1, backgroundColor: state.progressionMode === 'RPE' ? colors.primary : colors.card }}
              textStyle={{ color: state.progressionMode === 'RPE' ? '#fff' : colors.text }}
            />
            <Button
              text="%1RM"
              onPress={() => actions.setProgressionMode('PCT1RM')}
              style={{ flex: 1, backgroundColor: state.progressionMode === 'PCT1RM' ? colors.primary : colors.card }}
              textStyle={{ color: state.progressionMode === 'PCT1RM' ? '#fff' : colors.text }}
            />
          </View>

          <Text style={[styles.sectionTitle, { marginTop: 8 }]}>Goal</Text>
          <View style={{ flexDirection: 'row', gap: 8 }}>
            {(['loss', 'maintain', 'gain'] as const).map((g) => (
              <Button
                key={g}
                text={g.charAt(0).toUpperCase() + g.slice(1)}
                onPress={() => actions.setGoal(g)}
                style={{ flex: 1, backgroundColor: state.goal === g ? colors.primary : colors.card }}
                textStyle={{ color: state.goal === g ? '#fff' : colors.text }}
              />
            ))}
          </View>
        </View>
      </BottomSheetModal>

      <TouchableOpacity
        style={styles.fab}
        onPress={() => setSheetOpen(true)}
        accessibilityRole="button"
      >
        <Text style={styles.fabText}>⚙︎</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    justifyContent: 'space-between',
  },
  headerTitle: {
    color: colors.text,
    fontSize: 18,
    fontWeight: '700',
  },
  navButton: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    backgroundColor: colors.card,
    borderRadius: 8,
    boxShadow: '0 1px 2px rgba(0,0,0,0.06)',
  },
  navText: {
    color: colors.text,
    fontSize: 16,
    fontWeight: '700',
  },
  quickActions: {
    marginBottom: 12,
  },
  dayCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 12,
    marginBottom: 12,
    boxShadow: '0 2px 6px rgba(0,0,0,0.08)',
  },
  dayHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  dayTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.text,
  },
  shiftPill: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    backgroundColor: colors.backgroundAlt,
    borderRadius: 20,
  },
  shiftPillText: {
    color: colors.textMuted,
    fontSize: 12,
    fontWeight: '600',
  },
  section: {
    marginTop: 8,
  },
  sectionTitle: {
    color: colors.text,
    fontSize: 14,
    fontWeight: '700',
    marginBottom: 4,
  },
  bodyText: {
    color: colors.text,
    fontSize: 14,
  },
  mutedText: {
    color: colors.textMuted,
    fontSize: 13,
  },
  fab: {
    position: 'absolute',
    bottom: 24,
    right: 24,
    width: 54,
    height: 54,
    backgroundColor: colors.primary,
    borderRadius: 27,
    alignItems: 'center',
    justifyContent: 'center',
    boxShadow: '0 4px 12px rgba(15,98,254,0.4)',
  },
  fabText: {
    color: '#fff',
    fontSize: 24,
    fontWeight: '900',
  },
});
