
import { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TextInput, Switch } from 'react-native';
import { colors, commonStyles } from '../../styles/commonStyles';
import Button from '../../components/Button';
import { useApp } from '../../context/AppContext';
import ChatBubble from '../../components/ChatBubble';
import dayjs from 'dayjs';

export default function MessagesScreen() {
  const { state, actions } = useApp();
  const [text, setText] = useState('');
  const [urgent, setUrgent] = useState(false);

  const canReplyNow = actions.isWithinOfficeHours();

  const send = () => {
    if (!text.trim()) return;
    actions.sendMessage({
      text,
      from: 'client',
      urgent,
    });

    if (!canReplyNow) {
      actions.sendMessage({
        text: 'Thanks for your message. I will reply during office hours. If urgent and on-shift, I will prioritize.',
        from: 'coach',
        urgent: false,
        system: true,
      });
    }

    setText('');
    setUrgent(false);
  };

  return (
    <View style={[commonStyles.container, { padding: 12, justifyContent: 'flex-start' }]}>
      <Text style={styles.title}>Messaging</Text>
      <Text style={{ color: colors.textMuted, marginBottom: 8 }}>
        Office hours: {state.officeHours.start}:00–{state.officeHours.end}:00. Now: {dayjs().format('HH:mm')}
      </Text>
      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ paddingBottom: 80 }}>
        {state.messages.map((m) => (
          <ChatBubble key={m.id} message={m} />
        ))}
      </ScrollView>

      <View style={styles.composer}>
        <TextInput
          value={text}
          onChangeText={setText}
          placeholder="Type a message"
          placeholderTextColor={colors.textMuted}
          style={styles.input}
        />
        <View style={{ alignItems: 'center', justifyContent: 'center', marginHorizontal: 8 }}>
          <Text style={{ color: colors.textMuted, fontSize: 12 }}>Urgent</Text>
          <Switch value={urgent} onValueChange={setUrgent} />
        </View>
        <Button text="Voice" onPress={() => actions.addVoiceNote(urgent)} style={{ width: 80, backgroundColor: colors.accent }} />
        <View style={{ width: 8 }} />
        <Button text="Send" onPress={send} style={{ width: 90 }} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  title: {
    color: colors.text,
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 8,
  },
  composer: {
    position: 'absolute',
    bottom: 12,
    left: 12,
    right: 12,
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 8,
    flexDirection: 'row',
    alignItems: 'center',
    boxShadow: '0 2px 6px rgba(0,0,0,0.08)',
  },
  input: {
    flex: 1,
    backgroundColor: colors.backgroundAlt,
    color: colors.text,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderColor: colors.grey,
    borderWidth: 1,
  },
});
