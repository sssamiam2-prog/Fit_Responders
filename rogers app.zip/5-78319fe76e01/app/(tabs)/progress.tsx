
import { useState } from 'react';
import { View, Text, StyleSheet, Image, ScrollView } from 'react-native';
import { colors, commonStyles } from '../../styles/commonStyles';
import Button from '../../components/Button';
import * as ImagePicker from 'expo-image-picker';
import Graph from '../../components/Graph';
import { useApp } from '../../context/AppContext';

export default function ProgressScreen() {
  const [leftUri, setLeftUri] = useState<string | null>(null);
  const [rightUri, setRightUri] = useState<string | null>(null);
  const { state } = useApp();

  const pick = async (which: 'L' | 'R') => {
    const res = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: false,
      quality: 0.8,
    });
    if (!res.canceled && res.assets?.length) {
      const uri = res.assets[0].uri;
      if (which === 'L') setLeftUri(uri);
      else setRightUri(uri);
    }
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.background }} contentContainerStyle={{ padding: 16 }}>
      <Text style={styles.title}>Progress</Text>

      <View style={styles.compareRow}>
        <View style={styles.photoCard}>
          {leftUri ? <Image source={{ uri: leftUri }} style={styles.photo} /> : <Text style={styles.muted}>Select photo</Text>}
          <Button text="Pick Left" onPress={() => pick('L')} />
        </View>
        <View style={styles.photoCard}>
          {rightUri ? <Image source={{ uri: rightUri }} style={styles.photo} /> : <Text style={styles.muted}>Select photo</Text>}
          <Button text="Pick Right" onPress={() => pick('R')} />
        </View>
      </View>

      <View style={styles.card}>
        <Text style={styles.sectionTitle}>Weight Trend</Text>
        <Graph data={state.progress.weightTrend} />
      </View>

      <View style={styles.card}>
        <Text style={styles.sectionTitle}>Best Lifts</Text>
        <Graph data={state.progress.liftTrend} />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  title: {
    color: colors.text,
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 8,
  },
  compareRow: {
    flexDirection: 'row',
    gap: 12 as any,
    marginBottom: 12,
  },
  photoCard: {
    flex: 1,
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 12,
    alignItems: 'center',
    boxShadow: '0 2px 6px rgba(0,0,0,0.08)',
  },
  photo: {
    width: '100%',
    height: 220,
    borderRadius: 8,
    marginBottom: 8,
  },
  muted: {
    color: colors.textMuted,
    marginBottom: 8,
  },
  card: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 12,
    marginBottom: 12,
    boxShadow: '0 2px 6px rgba(0,0,0,0.08)',
  },
  sectionTitle: {
    color: colors.text,
    fontWeight: '800',
    marginBottom: 8,
  },
});
