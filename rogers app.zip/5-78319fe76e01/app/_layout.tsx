
import { Stack, useGlobalSearchParams } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { Platform } from 'react-native';
import { commonStyles } from '../styles/commonStyles';
import { useEffect, useMemo, useState } from 'react';
import { setupErrorLogging } from '../utils/errorLogger';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { AppProvider } from '../context/AppContext';

const STORAGE_KEY = 'emulated_device';

function InnerLayout() {
  const { emulate } = useGlobalSearchParams<{ emulate?: string }>();
  const [storedEmulate, setStoredEmulate] = useState<string | null>(null);

  useEffect(() => {
    setupErrorLogging();

    if (Platform.OS === 'web') {
      if (emulate) {
        localStorage.setItem(STORAGE_KEY, emulate);
        setStoredEmulate(emulate);
      } else {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) setStoredEmulate(stored);
      }
    }
  }, [emulate]);

  const paddingStyle = useMemo(() => {
    if (Platform.OS !== 'web') return {} as any;
    const simulatedInsets = {
      ios: { paddingTop: 47, paddingBottom: 20, paddingLeft: 0, paddingRight: 0 },
      android: { paddingTop: 40, paddingBottom: 0, paddingLeft: 0, paddingRight: 0 },
    } as const;
    const deviceToEmulate = storedEmulate || emulate;
    return (deviceToEmulate && simulatedInsets[deviceToEmulate as 'ios' | 'android']) || {};
  }, [storedEmulate, emulate]);

  return (
    <SafeAreaView style={[commonStyles.wrapper, paddingStyle]}>
      <StatusBar style="dark" />
      <AppProvider>
        <Stack screenOptions={{ headerShown: false, animation: 'default' }} />
      </AppProvider>
    </SafeAreaView>
  );
}

export default function RootLayout() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <InnerLayout />
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
